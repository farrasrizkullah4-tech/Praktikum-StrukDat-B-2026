angka = [10, 20, 30 , 40, 50]
angka.append(60)
print (angka)

angka   = [10, 20, 30 , 40, 50]
remove = angka.remove(20)
print (angka)

angka = [10, 20, 30 , 40, 50]

angka_tertinggi = max(angka)
print (angka_tertinggi)
angka_terendah = min(angka)
print (angka_terendah)

angka = [10, 20, 30 , 40, 50]
rata_rata = sum(angka)
print (rata_rata / len(angka))

