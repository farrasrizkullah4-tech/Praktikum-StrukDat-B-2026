mahasiswa = ("A001", "Budi", "Informatika")
print (mahasiswa)

for data in mahasiswa:
    print (data)

#tuple tidak bisa diubah karena bersifat immutable
