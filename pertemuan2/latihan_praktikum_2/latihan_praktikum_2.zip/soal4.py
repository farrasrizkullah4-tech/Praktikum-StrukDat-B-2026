mahasiswa = {
    "A001": {"nama": "Budi", "jurusan": "Informatika", "ipk" : 3.45},
    "A002": {"nama": "Siti", "jurusan": "Sistem Informasi", "ipk" : 3.20},
    "A003": {"nama": "Andi", "jurusan": "Informatika", "ipk" : 3.75}
            }   

# Mahasiswa yang memiliki ipk diatas 3.5






 

